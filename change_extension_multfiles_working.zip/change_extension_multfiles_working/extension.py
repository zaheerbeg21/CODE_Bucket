import os
from os import path


dir_path = r"F:/darknet_training/model_RAK_box_symbols/images"


def rename_ext():
    for count, file in enumerate(os.listdir(dir_path)):
        name, extension = path.splitext(file)
        # print(file)

        src = dir_path+os.sep+file
        # print("--", src)
        dst = dir_path+os.sep+name+ ".png"
        # print("==", dst)

        os.rename(src, dst)


if __name__ == '__main__':
    rename_ext()
