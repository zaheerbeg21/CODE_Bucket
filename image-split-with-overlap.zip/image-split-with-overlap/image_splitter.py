import os
from PIL import Image

INPUT_IMAGE = 'F:\Code\image-split-with-overlap\input_images\img_1.png'

if not os.path.exists('output_images'):
    os.mkdir('output_images')

def imgcrop(input, xPieces, yPieces):
    global count, arr_list
    filename, file_extension = os.path.splitext(input)
    im = Image.open(input)
    imgwidth, imgheight = im.size
    height = imgheight // yPieces
    width = imgwidth // xPieces
    for i in range(0, yPieces):
        for j in range(0, xPieces):
            box = (j * width, i * height, (j + 1) * width, (i + 1) * height)
            a = im.crop(box)
            a = a.convert('RGB')
            filename_to_save = 'output_images' + 'os.sep' + filename + "0" + str(i) + "0" + str(j) + file_extension
            a.save(filename_to_save)
            
imgcrop(INPUT_IMAGE, 3, 3)