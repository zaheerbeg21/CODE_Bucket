import cv2
import os

from os import listdir
from os.path import isfile, join

path_to_img = r"input_images/img4.jpg"
# print((path_to_img).split('/')[-1][:-4])


# onlyfiles = [f for f in listdir(path_to_img) if isfile(join(path_to_img, f))]


# print(onlyfiles)
# for f in listdir(path_to_img):
#     print(f)
print(path_to_img)
img = cv2.imread(path_to_img)
print(img[:-4])
img_h, img_w, _ = img.shape
# split_width = 150
# split_height = 150
split_width = int(img_w / 2)
split_height = int(img_h / 2)


def start_points(size, split_size, overlap=0):
    points = [0]
    stride = int(split_size * (1 - overlap))
    counter = 1
    while True:
        pt = stride * counter
        if pt + split_size >= size:
            points.append(size - split_size)
            break
        else:
            points.append(pt)
        counter += 1
    return points


X_points = start_points(img_w, split_width, 0)
Y_points = start_points(img_h, split_height, 0)

count = 0
name = (path_to_img).split('/')[-1][:-4]+'_splitted'
frmt = 'png'

for i in Y_points:
    for j in X_points:
        split = img[i:i + split_height, j:j + split_width]
        cv2.imwrite('output_images' + os.sep + '{}_{}.{}'.format(name, count, frmt), split)
        count += 1
