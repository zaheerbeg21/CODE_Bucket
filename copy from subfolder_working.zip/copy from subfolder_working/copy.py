import os
import shutil

source_path = 'dest_dir'
# destination_path = 'dest_dir'

mask_dir = '_mask'
src_dir = '_source'


for root, dirs, files in os.walk(source_path):  # replace the . with your starting directory
    for file in files:
        # print(file)
        if file.endswith('_mask.png'):
            # print(file)
            path_file = os.path.join(root, file)
            shutil.copy2(path_file, mask_dir)  # change you destination dir
        elif file.endswith('_source.png'):
            path_file = os.path.join(root, file)
            shutil.copy2(path_file, src_dir)

