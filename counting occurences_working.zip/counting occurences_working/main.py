import os
import sys

path = r'F:\darknet_training\LV_300\LV_1_and_2\labels - Copy'
save_path = r'F:\darknet_training\LV_300\LV_1_and_2'

a_list = []


### to read first character
def read_text_file(file_path):
    with open(file_path, 'r') as f:
        # print(f.read())
        lines = f.readlines()
        # print(lines)
        for line in lines:
            # print(line.split()[0])
            a_list.append(line.split()[0])
            a_list.sort()
    # print(a_list)


# to_read(path)
files = os.listdir(path)
# print("-->",files)
# #iterate through all file
for file in files:
    # #Check whether file is in text format or not
    if file.endswith(".txt"):
        file_path = path + os.sep + file

        # #call read text file function
        read_text_file(file_path)


def count_occurance(lst):
    letter_occurance = []
    occurance_counter = []
    for l in lst:
        if l in letter_occurance:
            ind = letter_occurance.index(l)
            val = occurance_counter[ind]
            occurance_counter.insert(ind, val + 1)
            occurance_counter.pop(ind + 1)
        else:
            letter_occurance.append(l)
            occurance_counter.append(1)
    return letter_occurance, occurance_counter


lo, oc = count_occurance(a_list)

file = 'symbol_count.txt'
# print(path.split('\\')[:-1])

# save_path = path.split()[:-1]+os.sep+file
save_path = save_path + os.sep + file

ctr_list = []
with open(save_path, 'w') as wr:
    for i, j in zip(lo, oc):
        # print("in zip")
        # print(i, j)
        # ctr_list.append([i, j])
        ctr_list.append([i, j])
        # print("after append- ",ctr_list)
    for ctl in ctr_list:
        wr.write(str(ctl)[1:-1])
        wr.write('\n')

print('file save -', save_path)
