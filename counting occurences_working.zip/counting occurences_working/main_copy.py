import os

path = r'F:\Code\delete_rows_using_first_char_working\new_dir'

a_list = []


# files = os.listdir(path)


### to read first character
def read_text_file(file_path):
    with open(file_path, 'r') as f:
        # print(f.read())
        lines = f.readlines()
        # print(lines)
        for line in lines:
            # print(line.split()[0])
            a_list.append(line.split()[0])
    # print(a_list)


# to_read(path)
files = os.listdir(path)
# print("-->",files)
# #iterate through all file
for file in files:
    # #Check whether file is in text format or not
    if file.endswith(".txt"):
        file_path = path + os.sep + file

        # #call read text file function
        read_text_file(file_path)


def count_occurance(lst):
    letter_occurance = []
    occurance_counter = []
    for l in lst:
        if l in letter_occurance:
            ind = letter_occurance.index(l)
            val = occurance_counter[ind]
            occurance_counter.insert(ind, val + 1)
            occurance_counter.pop(ind + 1)
        else:
            letter_occurance.append(l)
            occurance_counter.append(1)
    return letter_occurance, occurance_counter


lo, oc = count_occurance(a_list)

ctr_list = []
with open('count.txt', 'w') as wr:
    for i, j in zip(lo, oc):
        # print("in zip")
        print(i, j)
        ctr_list.append([i, j])

# print(ctr_list)
