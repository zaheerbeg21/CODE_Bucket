import glob, os, shutil

text_folder = r"F:\convert-yolo-to-pascalvoc\coco\outputs"
images_folder = r"F:\convert-yolo-to-pascalvoc\coco\images"







all_image_files = glob.glob(images_folder+os.sep+"*.png")
all_txt_files = glob.glob(text_folder+os.sep+"*.xml")

#print(all_image_files)
#print(all_txt_files)

for txt_file in all_txt_files:
    #print("-", txt_file)
    txt_filename = txt_file.split("\\")[-1]
    for img_file in all_image_files:
        #print(">", img_file)
        img_filename = img_file.split("\\")[-1]
        #print(img_filename)
        if txt_filename[:-4] == img_filename[:-4]:
            #print(txt_filename[:-4],img_filename[:-4])
            # shutil.copy(src, dst)
            print(text_folder+os.sep+img_filename)
            shutil.copy(img_file, text_folder+os.sep+img_filename)
            
