# Import the required Module
import tabula
from tabula import read_pdf


# from tabula import wrapper
# df = wrapper.read_pdf('101 Franklin - Exterior Wall Leveling_CMI_2021-07-08.pdf')


# Read a PDF File
df = tabula.read_pdf("101 Franklin - Exterior Wall Leveling_CMI_2021-07-08.pdf", pages='all')[0]
# convert PDF into CSV
tabula.convert_into("101 Franklin - Exterior Wall Leveling_CMI_2021-07-08.pdf", "iplmatch.csv", output_format="csv", pages='all')
# print(df)