# Import the required Module
import os
import glob

import tabula
from tabula import read_pdf

src_path = r'F:\Code\pdf_to_csv&excel_working\input_dir'
destination_path = 'save_dir'



# Extract all the list of items recursively
files = glob.glob(src_path + '**/*', recursive=True)

# Filter only files
files = [f for f in files if os.path.isfile(f)]

# Loop to print the filenames
for filename in files:
    # print(filename)
    # Read a PDF File
    df = tabula.read_pdf(filename, pages='all')[0]
    # #convert PDF into CSV
    tabula.convert_into(filename, filename[:-4]+'.csv', output_format="csv",pages='all')


# print(df)
