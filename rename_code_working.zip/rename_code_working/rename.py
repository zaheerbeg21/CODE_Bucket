import os
from os import path
import shutil

source_path = r'F:\xtreme_vision\dataset\zaheer'
destination_path = r'F:\xtreme_vision\dataset\rename'


# dst_folder = os.mkdir(destination_path)


def main():
    for count, filename in enumerate(os.listdir(source_path)):
        dst = "OCR_" + str(count) + ".png"
        print(dst)
        # rename all the files
        os.rename(os.path.join(source_path, filename), os.path.join(destination_path, dst))


# Driver Code
if __name__ == '__main__':
    main()
