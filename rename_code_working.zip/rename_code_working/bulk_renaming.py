import os
# Function to rename multiple files
def main():
   i = 1
   path=r'F:\UpWork\OCR_COllection\hotel receipt'
   save_path = r'F:\Code\In porgress\rename_code\output_file'
   
   
   for filename in os.listdir(path):
      file_ ="images - 2021-07-28T170153" + str(i) + ".jpeg"
      my_source = path+os.sep + filename
      print(my_source)
      my_dest = save_path +os.sep + file_
      print( my_dest)
      # rename() function will
      # rename all the files
      os.rename(my_source, my_dest)
      i += 1
# Driver Code
if __name__ == '__main__':
   # Calling main() function
   main()