from pdf2image import convert_from_path
import os

# NOTE - conda environment pdf2img_env environment


# The path for listing items
path = r'F:\UpWork\OCR_Lucky\PDF_Onedrive'

# The list of items
files = os.listdir(path)

output = r'F:\UpWork\OCR_Lucky\Images_Onedrive'

# Loop to print each filename separately
for filename in files:
    # print(filename)
    input_pdf = filename


def convert_pdf_to_images(pdf_path):
    images = convert_from_path(pdf_path)
    for index, image in enumerate(images):
        image.save(output + os.sep + f'/{pdf_path}-{index}.png')
        print(output + os.sep + f'{pdf_path}-{index}.png')


def task():
    convert_pdf_to_images(input_pdf)
    # convert_pdf_to_images('example-multipage.pdf')


if __name__ == "__main__":
    task()
