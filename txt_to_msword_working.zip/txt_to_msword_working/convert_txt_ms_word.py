from docx import Document

#NOTE - Use python 3.6 interrpreter

import os
#
doc = Document()

path = r"F:\Code\OCR_Extraction_Working\doctor_text - Copy"
file_name = os.listdir(path)

for i in file_name:
    print(i)
    img_name = path + os.sep + i

    with open(img_name, 'r', encoding='latin-1') as openfile:
        line = openfile.read()
        doc.add_paragraph(line)
        doc.save('ms_doc_dir' + os.sep + i[:-4] + ".docx")

    os.system(i[:-4] + ".docx")

