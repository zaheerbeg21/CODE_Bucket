import os

from PIL import Image
import glob

input_path = r'F:\Code\In porgress\cropper_working\input_images'

# print(glob.glob(os.path.join(input_path, '*')))
list_files = glob.glob(os.path.join(input_path, '*'))
# print(list_files)

ctr = 1
for fl in list_files:
    # print(fl)
    img = Image.open(fl)
    img2 = img.crop((1369, 1103, 4573, 3793))
    img2.save('side_cropped_images' + os.sep + 'img' + '_' + str(ctr) + '.png')
    ctr += 1
#

# for
# img = Image.open("20200203 RP Comment.pdf-5.png")
# img2 = img.crop((1369, 1103, 4573, 3793))
# img2.save("img4.jpg")
