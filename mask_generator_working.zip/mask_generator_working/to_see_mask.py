## View data such as pictures and masks in the PennFudanPed dataset
from PIL import Image
mask = Image.open('F:\mask_generator_working\curve_0_json\curve_0_mask.png').convert('L')

mask.putpalette([0, 0, 0,     #　Putpalette adds a palette to the object, which is equivalent to coloring: the background is black, the target 1 is red, the target 2 is yellow, and the target 3 is orange (if you have more targets in the picture, you can add more by yourself) Toning value)
                 255, 0, 0,
                 255, 255, 0,
                 255, 153, 0])
mask.show()  # View the effect of mask coloring
