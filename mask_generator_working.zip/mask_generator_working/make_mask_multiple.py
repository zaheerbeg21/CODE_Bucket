import os
import cv2
import json
import numpy as np
import glob

image_folder = os.path.join(os.getcwd(), "images_dir")
json_folder = r"F:\mask_generator_working\json_directory"  # Relative to root directory

count = 0  # Count of total image_dir saved
file_bbs = {}  # Dictionary containing polygon coordinates for mask
MASK_WIDTH = 5000  # Dimensions should match those of ground truth image
MASK_HEIGHT = 4156

mask_images = r'F:\mask_generator_working\mask_dir'  # save masked image_dir

# masked
mask = np.zeros((MASK_WIDTH, MASK_HEIGHT))


# Extract X and Y coordinates if available and update dictionary
def add_to_dict(data, itr, key, count):
    try:
        x_points = data[itr]["regions"][count]["shape_attributes"]["all_points_x"]
        y_points = data[itr]["regions"][count]["shape_attributes"]["all_points_y"]
    except:
        print("No BB. Skipping", key)
        return

    all_points = []
    for i, x in enumerate(x_points):
        all_points.append([x, y_points[i]])

    file_bbs[key] = all_points


jfl = ''
file_name_json = ''
img_file = ''

images_ = r"F:\mask_generator_working\image_dir"
json_ = r"F:\mask_generator_working\json_directory"

all_image_files = glob.glob(images_ + os.sep + "*.png")
all_jsn_files = glob.glob(json_ + os.sep + "*.json")

# print(all_image_files)
# print(all_jsn_files)

for txt_jfile in all_jsn_files:
    # print("-", txt_jfile)

    txt_filename = txt_jfile.split("\\")[-1]
    # print("# ", txt_filename[:-5])
    jfile = txt_filename[:-5]
    for img_file in all_image_files:
        # print(">", img_file)
        img_filename = img_file.split("\\")[-1]
        # print("$ ", img_filename[:-4])
        img_file = img_filename[:-4]
        if jfile == img_file:
            for dir_, _, jsonfile in os.walk(json_folder):
                # print("jfl", jsonfile)
                for jfl in jsonfile:
                    # print(jfl)
                    # Read JSON file
                    with open(os.path.join(dir_, jfl)) as f:
                        data = json.load(f)
                        # print("data = >", data)

                # print(">>",jfl)

            for itr in data:
                # print("-->",itr)
                file_name_json = data[itr]["filename"]  # get imagename here
                # print("file_name_json ##", file_name_json)
                sub_count = 0  # Contains count of masks for a single ground truth image

                if len(data[itr]["regions"]) > 1:
                    for _ in range(len(data[itr]["regions"])):
                        key = file_name_json[:-4] + "*" + str(sub_count + 1)
                        add_to_dict(data, itr, key, sub_count)
                        sub_count += 1
                else:
                    add_to_dict(data, itr, file_name_json[:-4], 0)

            # print("\nDict size: ", len(file_bbs))
            mask_folder = ''
            for itr in file_bbs:
                num_masks = itr.split("*")
                to_save_folder = os.path.join(mask_images, num_masks[0])
                mask_folder = os.path.join(to_save_folder, "masks")

                try:
                    arr = np.array(file_bbs[itr])
                    # print("arr-", arr)
                except:
                    print("Not found:", itr)
                    continue
                # count += 1
                for ar in arr:
                    cv2.fillPoly(mask, [arr], color=1)

            cv2.imwrite(mask_images + os.sep + img_file + "_mask.png", mask)

# print("Images saved:", image_folder + os.sep + jfl + "_mask.png")
