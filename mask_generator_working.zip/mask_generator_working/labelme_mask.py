import sys

import cv2, csv
import numpy as np
import re

file = 'curve_0.txt'

int_list = []
# reading csv file
with open(file, 'r') as csv_file:
    # print(file)
    # creating a csv reader object
    reader = csv.reader(csv_file)
    for i in reader:
        # print(i)
        # print(len(i))
        # print("i>", '[%s]' % ','.join(map(str, i))[:-1])  # remove quotes from integers
        quotes_less = '%s' % ','.join(map(str, i))[:-1]  # gives string list
        # print(type(','.join(i)))
        # print(type('[%s]' % ','.join(i)[:-1]))
        # int_list = [round(int(num)) for num in quotes_less]
        p = set(round(float(x)) for x in i if re.fullmatch("\d.+", x) is not None)
        # print(type(p))
        int_list.append(p)
        # print(len(p))

# print(int_list)

MASK_WIDTH = 5000  # Dimensions should match those of ground truth image
MASK_HEIGHT = 4156

image = np.zeros((MASK_WIDTH, MASK_HEIGHT))
for pts in int_list:
    contours = np.array(pts)
    # print(contours)
    # for k in int_list:
    # print(k)
    # contours = np.array(int_list, dtype=object)
    # print(contours)

    # image = np.zeros((MASK_WIDTH, MASK_HEIGHT))
    # x = cv2.fillPoly(image, contours, color = (255, 255, 255))
    # cv2.imshow("filledPolygon", image)


img_path = r'F:\mask_generator_working\image_dir\curve_0.png'
img = cv2.imread(img_path)
cv2.imwrite("mash_gen.png", image)
