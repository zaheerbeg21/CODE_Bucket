NOTE - Kindly use python 3.6 interpreter

#READ -https://www.programmersought.com/article/54764300494/

#for bulk mask images use make_mask_multiple.py
- image with json file in respective image and json folders and ouput will be at mask_dir folder


# If you want mask with yaml 
	- kindly python labelme_json_to_dataset.py  json_directory

#Mask images with yaml and all - >
================================
InstalledlabelmeAfter that, uselabelmeAnnotate the pictures, you can get the corresponding to each picture.jsonFiles, generally all.jsonThe files and all pictures are placed in the same folder.

Create a folder (this folder is used to store your converted files)
Right click in the folder and select "Open terminal”
activationlabelmesurroundings
Enter the command in the terminal:labelme_json_to_dataset + (the folder where the .json file is located), For example my command islabelme_json_to_dataset　../JSONFiless(mine.jsonThe file is placed in the upper directory of the folder where it is nowJSONFilessFolder)