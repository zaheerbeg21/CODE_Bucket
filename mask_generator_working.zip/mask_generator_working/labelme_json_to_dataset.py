import argparse
import json
import os
import os.path as osp
import warnings
import copy
import numpy as np
import PIL.Image
from skimage import io
import yaml
from labelme import utils


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('json_file')  # j   folder
    parser.add_argument('-o', '--out', default=None)
    args = parser.parse_args()

    json_file = args.json_file

    list = os.listdir(json_file)  # Get a list of JSON files
    for i in range(0, len(list)):
        path = os.path.join(json_file, list[i])  # Get absolute paths for each JSON file
        print(path)
        filename = list[i][:-5]  # Extract the characters before. Json as the file name so as to save the Label picture.
        extension = list[i][-4:]
        if extension == 'json':
            if os.path.isfile(path):
                data = json.load(open(path))
                img = utils.image.img_b64_to_arr(data['imageData'])  # You can get the original image according to the characters of the 'ImageData' field
                # lbl is the Label picture (the number corresponding to the class name of the class, the other 0) LBL_NAMES is the corresponding relationship dictionary of the Label name and the number.
                lbl, lbl_names = utils.shape.labelme_shapes_to_label(img.shape, data[
                    'shapes'])  # Data ['Shapes'] is a field that records the position of the label and Label information in the JSON file.

                # captions = ['%d: %s' % (l, name) for l, name in enumerate(lbl_names)]
                # lbl_viz = utils.draw.draw_label(lbl, img, captions)
                out_dir = osp.basename(list[i])[:-5] + '_json'
                out_dir = osp.join(osp.dirname(list[i]), out_dir)
                if not osp.exists(out_dir):
                    os.mkdir(out_dir)

                PIL.Image.fromarray(img).save(osp.join(out_dir, '{}_source.png'.format(filename)))
                PIL.Image.fromarray(lbl).save(osp.join(out_dir, '{}_mask.png'.format(filename)))
                # PIL.Image.fromarray(lbl_viz).save(osp.join(out_dir, '{}_viz.jpg'.format(filename)))

                with open(osp.join(out_dir, 'label_names.txt'), 'w') as f:
                    for lbl_name in lbl_names:
                        f.write(lbl_name + '\n')

                warnings.warn('info.yaml is being replaced by label_names.txt')
                info = dict(label_names=lbl_names)
                with open(osp.join(out_dir, 'info.yaml'), 'w') as f:
                    yaml.safe_dump(info, f, default_flow_style=False)

                print('Saved to: %s' % out_dir)


if __name__ == '__main__':
    main()
