# Importing libraries
from image_slicer import slice
import os

# The path for listing items
input_img_path = 'input_images'
save_img_path = 'output_images'
split_count = 4


def img_slicer_fun(dir_path):
    # The list of items
    images = os.listdir(dir_path)
    # Loop to print each filename separately
    for imgs in images:
        # print(imgs)
        slice(imgs, split_count)


img_slicer_fun(input_img_path)

# slice('curve_0.png', 4)
