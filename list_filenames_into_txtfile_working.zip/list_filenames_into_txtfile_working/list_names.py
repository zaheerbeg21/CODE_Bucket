#!/usr/bin/python

import os

# start editable vars #
outputfile = "train.txt"  # file to save the results to
folder = r"F:\darknet_training\OCR_UpWala\images"  # the folder to inventory
exclude = ['Thumbs.db', '.tmp']  # exclude files containing these strings
pathsep = "/"  # path seperator ('/' for linux, '\' for Windows)
# end editable vars #

with open(outputfile, "w") as txtfile:
    for path, dirs, files in os.walk(folder):
        for fn in sorted(files):
            if not any(x in fn for x in exclude):
                # filename = os.path.splitext(fn)[0]
                filename = fn
                print(filename)
                txtfile.write("/data/OCR_UpWala/images/"+"%s\n" % filename)

txtfile.close()
