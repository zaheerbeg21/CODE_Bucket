import os
import sys

path = r'F:\Code\temp\delete_rows_using_first_char\labels - Copy'
# print(file_path)
# sys.exit()


# Change the directory
os.chdir(path)

temp_path = r'F:\Code\temp\delete_rows_using_first_char\new_dir'

# Read text File
def read_text_file(file_path):
    with open(file_path, 'r') as f:
        # print(f.read())
        lines = f.readlines()
        # print(lines)
        for line in lines:
            if not line.startswith('7'):
                # print(line)
                save_path = temp_path + os.sep + file
                f = open(save_path, "w")
                for line in lines:
                    if not line.startswith('7'):
                        f.write(line)
                        # print("-->",line)
                        # sys.exit()

# #iterate through all file
for file in os.listdir():
    # #Check whether file is in text format or not
    if file.endswith(".txt"):
        file_path = path + os.sep + file

        # #call read text file function
        read_text_file(file_path)


