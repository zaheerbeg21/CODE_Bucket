import os

from PyPDF2 import PdfFileWriter, PdfFileReader

path = r'F:\UpWork\AAAA\ResearchPaper(English)'

save_dir = 'split_dir'

list_pdf = os.listdir(path)

for filename in list_pdf:
    # print(filename)
    file_path = path+os.sep+filename
    inputpdf = PdfFileReader(open(file_path, "rb"))
    for i in range(inputpdf.numPages):
        output = PdfFileWriter()
        output.addPage(inputpdf.getPage(i))
        save_file_as = save_dir + os.sep + filename[:-4] + "%s.pdf" % i
        with open(save_file_as, "wb") as outputStream:
            output.write(outputStream)
