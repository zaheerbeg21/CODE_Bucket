import os

from PyPDF2 import PdfFileWriter, PdfFileReader

file_name = "2019 Sustainability Report.pdf"
save_dir = 'split_dir'

inputpdf = PdfFileReader(open(file_name, "rb"))

for i in range(inputpdf.numPages):
    output = PdfFileWriter()
    output.addPage(inputpdf.getPage(i))
    save_file_as = save_dir + os.sep + file_name[:-4] + "%s.pdf" % i
    with open(save_file_as, "wb") as outputStream:
        output.write(outputStream)
