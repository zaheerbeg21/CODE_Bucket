import os

save_path = 'rename_dir'

if not os.path.exists(save_path):
    os.mkdir(save_path)

path = r'F:\Code\OCR_Extraction_Working\doctor_text - Copy'
print(path)
for file in os.listdir(path):
    # print(file[5:-17]+'.txt')
    # print(f"/rename_dir\Dr_Koller_Buch_{file[5:-17] + '.txt'}")
    os.rename(path + os.sep + file, f"rename_dir/Dr_Koller_Buch_{file[5:-17] + '.txt'}")
